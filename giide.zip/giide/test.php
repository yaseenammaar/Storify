<?php
for ($i=0,$i++; $i < 6;) {
  print $i;
  $i=$i+3;
}
 ?>
