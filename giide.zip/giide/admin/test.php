<?php
echo "hello";
echo $ffmpegPath = shell_exec('which ffmpeg');
echo $ffprobe = exec('which ffprobe');
 ?>
