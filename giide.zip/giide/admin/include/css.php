<link href="../lib/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
<link href="../lib/ionicons/css/ionicons.min.css" rel="stylesheet">
<link href="../lib/jqvmap/jqvmap.min.css" rel="stylesheet">
<link href="../lib/datatables.net-dt/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="../lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/dashforge.css">
<link rel="stylesheet" href="../assets/css/dashforge.dashboard.css">
