<?php $adminDetails=getAdminDetails($adminId); ?>
<aside class="aside aside-fixed">
  <div class="aside-header">
    <a href="dashboard.php" class="aside-logo">Giide<span>App</span></a>
    <a href="" class="aside-menu-link">
      <i data-feather="menu"></i>
      <i data-feather="x"></i>
    </a>
  </div>
<?php include('include/sidebar.php'); ?>
