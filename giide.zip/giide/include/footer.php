<footer class="footer">
  <div>
    <span>&copy; 2022 Giide App. </span>
    <!-- <span>Created by <a href="#">ThemePixels</a></span> -->
  </div>
  <div>
    <nav class="nav">
      <a href="#" class="nav-link">Terms & Condition</a>
      <a href="#" class="nav-link">Privacy Policy</a>
      <a href="#" class="nav-link">Get Help</a>
    </nav>
  </div>
</footer>
