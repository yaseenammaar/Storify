<?php
	$Global['host']="localhost";
	$Global['username']="root";
	$Global['password']="";
	$Global['database']="gofeeds";
	$Global['baseurl']='';
	date_default_timezone_set('Asia/Kolkata');
?>
