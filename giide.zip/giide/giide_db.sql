-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2022 at 03:12 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gofeeds`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email_id` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_date` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email_id`, `password`, `photo`, `is_active`, `is_deleted`, `created_date`) VALUES
(1, 'Admin', 'admin@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '256.png', 1, 0, '2021-12-16 18:14:26');

-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

CREATE TABLE `audio` (
  `id` bigint(20) NOT NULL,
  `file` text DEFAULT NULL,
  `name` text DEFAULT NULL,
  `duration` varchar(10) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `logo` varchar(250) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `date` varchar(25) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `chapter`
--

CREATE TABLE `chapter` (
  `id` bigint(20) NOT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `audio_id` varchar(20) DEFAULT NULL,
  `audio_file` varchar(250) DEFAULT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `color` varchar(20) DEFAULT NULL,
  `brand` varchar(10) NOT NULL,
  `desp` text DEFAULT NULL,
  `author` varchar(250) DEFAULT NULL,
  `status` enum('0','1') DEFAULT NULL,
  `username` varchar(250) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `likes` varchar(250) DEFAULT NULL,
  `love` varchar(250) DEFAULT NULL,
  `happy` varchar(250) DEFAULT NULL,
  `sad` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `country_language_code`
--

CREATE TABLE `country_language_code` (
  `id` int(11) NOT NULL,
  `country` varchar(50) NOT NULL,
  `language` varchar(50) NOT NULL,
  `code` varchar(10) NOT NULL,
  `flag` varchar(10) NOT NULL,
  `status` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `country_language_code`
--

INSERT INTO `country_language_code` (`id`, `country`, `language`, `code`, `flag`, `status`) VALUES
(1, 'South Africa', 'Afrikaans', 'af-ZA', 'za', '1'),
(2, 'India', 'Bengali', 'bn-IN', 'in', '1'),
(3, 'Bulgaria', 'Bulgarian', 'bg-BG', 'bg', '1'),
(4, 'Spain', 'Catalan', 'ca-ES', 'es', '1'),
(5, 'Hongkong', 'Chinese', 'yue-HK', 'hk', '1'),
(6, 'Czech Republic', 'Czech', 'cs-CZ', 'cz', '1'),
(7, 'Denmark', 'Danish', 'da-DK', 'dk', '1'),
(8, 'Belgium', 'Dutch', 'nl-BE', 'be', '1'),
(9, 'Netherlands', 'Dutch', 'nl-NL', 'nl', '1'),
(10, 'Australia', 'English', 'en-AU', 'au', '1'),
(11, 'India', 'English', 'en-IN', 'in', '1'),
(12, 'UK', 'English', 'en-GB', 'gb', '1'),
(13, 'US', 'English', 'en-US', 'us', '1'),
(14, 'Philippiense', 'Filipino', 'fil-PH', 'ph', '1'),
(15, 'Finland', 'Finnish', 'fi-FI', 'fi', '1'),
(16, 'Canada', 'French', 'fr-CA', 'ca', '1'),
(17, 'France', 'French', 'fr-FR', 'fr', '1'),
(18, 'Germany', 'German', 'de-DE', 'de', '1'),
(19, 'Greece', 'Greek', 'el-GR', 'gr', '1'),
(20, 'India', 'Gujrati', 'gu-IN', 'in', '1'),
(21, 'Hungary', 'Hungarian', 'hu-HU', 'hu', '1'),
(22, 'India', 'Hindi', 'hi-IN', 'in', '1'),
(23, 'Iceland', 'Icelandic', 'is-IS', 'is', '1'),
(24, 'Indonesia', 'Indonesian', 'id-ID', 'id', '1'),
(25, 'Italy', 'Italian', 'it-IT', 'it', '1'),
(26, 'Japan', 'Japanese', 'ja-JP', 'jp', '1'),
(27, 'India', 'Kannada', 'kn-IN', 'in', '1'),
(28, 'South Koria', 'Korian', 'ko-KR', 'kr', '1'),
(29, 'Malaysia', 'Malay', 'ms-MY', 'my', '1'),
(30, 'India', 'Malyalam', 'ml-IN', 'in', '1'),
(31, 'Chinese', 'Mandarin', 'cmn-CN', 'cn', '1'),
(32, 'Norway', 'Norwegian', 'nb-NO', 'no', '1'),
(33, 'Poland', 'Polish', 'pl-PL', 'pl', '1'),
(34, 'Brazil', 'Portuguese', 'pt-BR', 'br', '1'),
(35, 'Portugal', 'Portuguese', 'pt-PT', 'pt', '1'),
(36, 'India', 'Punjabi', 'pa-IN', 'in', '1'),
(37, 'Romania', 'Romanian', 'ro-RO', 'ro', '1'),
(38, 'Russia', 'Russian', 'ru-RU', 'ru', '1'),
(39, 'Spain', 'Spanish', 'es-ES', 'es', '1'),
(40, 'US', 'Spanish', 'es-US', 'us', '1'),
(41, 'Swedan', 'Swedish', 'sv-SE', 'se', '1'),
(42, 'India', 'Tamil', 'ta-IN', 'in', '1'),
(43, 'Turkey', 'Turkish', 'tr-TR', 'tr', '1'),
(44, 'Thailand', 'Thai', 'th-TH', 'th', '1'),
(45, 'Ukraine', 'Ukrainian', 'uk-UA', 'ua', '1'),
(46, 'Vietnam', 'Vietnamese', 'vi-VN', 'vn', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customdomain`
--

CREATE TABLE `customdomain` (
  `id` int(11) NOT NULL,
  `user_id` varchar(500) DEFAULT NULL,
  `domain` varchar(500) DEFAULT NULL,
  `cname` varchar(500) DEFAULT NULL,
  `domain_verify` varchar(20) DEFAULT NULL,
  `cname_verify` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customdomain`
--

INSERT INTO `customdomain` (`id`, `user_id`, `domain`, `cname`, `domain_verify`, `cname_verify`, `date`, `time`) VALUES
(4, '1', 'localhost', '3.231.128.6', '1', '0', '2022-04-27', '11:04:45');

-- --------------------------------------------------------

--
-- Table structure for table `feeds`
--

CREATE TABLE `feeds` (
  `id` bigint(20) NOT NULL,
  `name` varchar(500) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL,
  `time` varchar(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `status` enum('0','1') NOT NULL,
  `likes` varchar(250) DEFAULT NULL,
  `love` varchar(250) DEFAULT NULL,
  `happy` varchar(250) DEFAULT NULL,
  `sad` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feeds`
--

INSERT INTO `feeds` (`id`, `name`, `date`, `time`, `user_id`, `status`, `likes`, `love`, `happy`, `sad`) VALUES
(1, 'New Test', '2022-04-12', '06:00 56pm', 1, '0', NULL, NULL, NULL, NULL),
(2, 'New Test', '2022-04-12', '06:00 56pm', 3, '0', NULL, '3', NULL, NULL),
(3, 'New Test', '2022-04-12', '06:00 56pm', 3, '1', NULL, NULL, NULL, NULL),
(4, 'New Test', '2022-04-12', '06:00 56pm', 4, '0', NULL, NULL, NULL, NULL),
(5, 'test', '2022-04-12', '07:07 34pm', 1, '1', NULL, NULL, NULL, NULL),
(6, 'new feed', '2022-04-12', '07:51 14pm', 1, '1', NULL, NULL, '3', NULL),
(7, 'feedplay123', '2022-06-05', '03:54 52pm', 1, '0', NULL, NULL, NULL, NULL),
(8, 'yuiyuiy', '2022-06-06', '07:33 11pm', 1, '0', NULL, NULL, NULL, NULL),
(9, 'new giide test', '2022-06-06', '07:36 40pm', 1, '1', NULL, NULL, NULL, NULL),
(10, 'giidenew', '2022-06-06', '07:59 47pm', 1, '0', NULL, NULL, NULL, NULL),
(11, 'newgiidetest', '2022-06-06', '08:05 53pm', 1, '0', NULL, NULL, NULL, NULL),
(12, 'giide34', '2022-06-06', '08:07 33pm', 1, '0', NULL, NULL, NULL, NULL),
(13, 'giidenew testt', '2022-06-06', '08:09 10pm', 1, '1', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `feed_defination`
--

CREATE TABLE `feed_defination` (
  `id` bigint(20) NOT NULL,
  `chapter_id` varchar(10) DEFAULT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `content_id` varchar(10) DEFAULT NULL,
  `ctime` varchar(20) NOT NULL,
  `defination` text DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feed_defination`
--

INSERT INTO `feed_defination` (`id`, `chapter_id`, `feed_id`, `content_id`, `ctime`, `defination`, `user_id`) VALUES
(1, '2', '5', '66', '0.38', 'asdasdasd', '1'),
(2, '13', '11', '4', '0.02', 'hello', '1');

-- --------------------------------------------------------

--
-- Table structure for table `feed_highlight`
--

CREATE TABLE `feed_highlight` (
  `id` bigint(20) NOT NULL,
  `content_id` int(11) NOT NULL,
  `ctime` varchar(25) NOT NULL,
  `chapter_id` varchar(10) DEFAULT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `highlight` text DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feed_highlight`
--

INSERT INTO `feed_highlight` (`id`, `content_id`, `ctime`, `chapter_id`, `feed_id`, `highlight`, `user_id`) VALUES
(1, 84, '0.48', '2', '5', 'asdasdasd', '1'),
(2, 23, '0.16', '4', '6', 'bjbkjjkh', '1'),
(3, 63, '0.41', '15', '13', 'xcbvvbcxvbcvb', '1');

-- --------------------------------------------------------

--
-- Table structure for table `feed_image`
--

CREATE TABLE `feed_image` (
  `id` bigint(20) NOT NULL,
  `chapter_id` varchar(10) DEFAULT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `content_id` varchar(10) DEFAULT NULL,
  `ctime` varchar(25) NOT NULL,
  `image` text DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feed_image`
--

INSERT INTO `feed_image` (`id`, `chapter_id`, `feed_id`, `content_id`, `ctime`, `image`, `caption`, `user_id`) VALUES
(1, '11', '9', '47', '', 'trans.png', 'sdfgdfgdfsgdfg', '1'),
(2, '15', '13', '126', '', 'socail2.png', 'xcvbcvb', '1');

-- --------------------------------------------------------

--
-- Table structure for table `feed_list`
--

CREATE TABLE `feed_list` (
  `id` bigint(20) NOT NULL,
  `chapter_id` varchar(10) DEFAULT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `content_id` varchar(10) DEFAULT NULL,
  `list` text DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feed_profile`
--

CREATE TABLE `feed_profile` (
  `id` bigint(20) NOT NULL,
  `chapter_id` varchar(10) DEFAULT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `content_id` varchar(10) DEFAULT NULL,
  `ctime` varchar(25) NOT NULL,
  `image` text DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `twitter` varchar(250) DEFAULT NULL,
  `linkedin` varchar(250) DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feed_quote`
--

CREATE TABLE `feed_quote` (
  `id` bigint(20) NOT NULL,
  `content_id` varchar(20) DEFAULT NULL,
  `ctime` varchar(25) NOT NULL,
  `chapter_id` varchar(10) DEFAULT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `quote` text DEFAULT NULL,
  `author` varchar(250) DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feed_url`
--

CREATE TABLE `feed_url` (
  `id` bigint(20) NOT NULL,
  `content_id` varchar(25) DEFAULT NULL,
  `ctime` varchar(25) NOT NULL,
  `chapter_id` varchar(10) DEFAULT NULL,
  `feed_id` varchar(10) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `source` varchar(500) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `id` int(11) NOT NULL,
  `user_limit` varchar(255) DEFAULT NULL,
  `workspace_limit` int(11) NOT NULL,
  `feed_limit` varchar(255) DEFAULT NULL,
  `chapter_limit` varchar(255) DEFAULT NULL,
  `audio_limit` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `monthly` decimal(60,0) NOT NULL,
  `yearly` decimal(60,0) DEFAULT NULL,
  `type` varchar(10) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `texttospeech`
--

CREATE TABLE `texttospeech` (
  `id` bigint(20) NOT NULL,
  `language` varchar(100) NOT NULL,
  `lang` varchar(25) NOT NULL,
  `voice` varchar(10) NOT NULL,
  `text` text NOT NULL,
  `audio` varchar(250) NOT NULL,
  `embed` varchar(250) NOT NULL,
  `date` varchar(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `status` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `wid` varchar(10) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email_id` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `contact_no` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `pin_code` varchar(50) DEFAULT NULL,
  `user_type` varchar(20) DEFAULT NULL,
  `package` varchar(2) DEFAULT NULL,
  `package_type` varchar(2) DEFAULT NULL,
  `expiry` varchar(20) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `company` varchar(250) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `website` varchar(250) DEFAULT NULL,
  `twitter` varchar(50) DEFAULT NULL,
  `facebook` varchar(250) DEFAULT NULL,
  `google` varchar(250) DEFAULT NULL,
  `linkedin` varchar(300) NOT NULL,
  `instagram` varchar(300) NOT NULL,
  `is_verified` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `created_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `wid`, `name`, `email_id`, `password`, `contact_no`, `address`, `pin_code`, `user_type`, `package`, `package_type`, `expiry`, `photo`, `company`, `bio`, `dob`, `country`, `website`, `twitter`, `facebook`, `google`, `linkedin`, `instagram`, `is_verified`, `created_by`, `is_active`, `is_deleted`, `created_date`) VALUES
(1, NULL, 'Test', 'test@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '7897987979', NULL, NULL, '1', '1', '1', '2023-04-12', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '', 0, 0, 1, 0, '2022-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `worksapce`
--

CREATE TABLE `worksapce` (
  `id` bigint(20) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `logo` varchar(300) DEFAULT NULL,
  `name` varchar(300) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `status` varchar(2) DEFAULT NULL,
  `is_deleted` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worksapce`
--

INSERT INTO `worksapce` (`id`, `user_id`, `logo`, `name`, `email`, `status`, `is_deleted`) VALUES
(1, '1', '256.png', 'My Team2', NULL, '1', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audio`
--
ALTER TABLE `audio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chapter`
--
ALTER TABLE `chapter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `country_language_code`
--
ALTER TABLE `country_language_code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customdomain`
--
ALTER TABLE `customdomain`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feeds`
--
ALTER TABLE `feeds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_defination`
--
ALTER TABLE `feed_defination`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_highlight`
--
ALTER TABLE `feed_highlight`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_image`
--
ALTER TABLE `feed_image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_list`
--
ALTER TABLE `feed_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_profile`
--
ALTER TABLE `feed_profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_quote`
--
ALTER TABLE `feed_quote`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_url`
--
ALTER TABLE `feed_url`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `texttospeech`
--
ALTER TABLE `texttospeech`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worksapce`
--
ALTER TABLE `worksapce`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audio`
--
ALTER TABLE `audio`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `chapter`
--
ALTER TABLE `chapter`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `country_language_code`
--
ALTER TABLE `country_language_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `customdomain`
--
ALTER TABLE `customdomain`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feeds`
--
ALTER TABLE `feeds`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `feed_defination`
--
ALTER TABLE `feed_defination`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feed_highlight`
--
ALTER TABLE `feed_highlight`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feed_image`
--
ALTER TABLE `feed_image`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `feed_list`
--
ALTER TABLE `feed_list`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feed_profile`
--
ALTER TABLE `feed_profile`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feed_quote`
--
ALTER TABLE `feed_quote`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feed_url`
--
ALTER TABLE `feed_url`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `texttospeech`
--
ALTER TABLE `texttospeech`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `worksapce`
--
ALTER TABLE `worksapce`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
