(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [236],
  {
    6440: function (a, b, c) {
      (window.__NEXT_P = window.__NEXT_P || []).push([
        "/resources/[slug]",
        function () {
          return c(1538);
        },
      ]);
    },
    1538: function (c, b, a) {
      "use strict";
      a.r(b),
        a.d(b, {
          __N_SSG: function () {
            return e;
          },
          default: function () {
            return d.Z;
          },
        });
      var d = a(6600),
        e = !0;
    },
  },
  function (a) {
    a.O(0, [680, 432, 484, 429, 599, 600, 774, 888, 179], function () {
      return a((a.s = 6440));
    }),
      (_N_E = a.O());
  },
]);
